import java.util.Scanner;
public class VehicleMain {
	public static void main(String[] args) {
		
		Scanner SCAN= new Scanner(System.in);
		System.out.println("Increase speed (to accelerate): ");
		int accel = SCAN.nextInt();		
		System.out.println("Decrease speed (to brake): ");
		int brake = SCAN.nextInt();
		System.out.println("Colour: ");
		String colour = SCAN.nextLine();
		System.out.println("# Doors: ");
		int doors = SCAN.nextInt();
		System.out.println("License plate: ");
		String licensePlate = SCAN.nextLine();
		
		
		
	}




}
