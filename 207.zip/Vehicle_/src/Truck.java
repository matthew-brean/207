
public class Truck {

	//properties
	//this._speed
	
}
